
from sklearn.decomposition import PCA
pca = PCA(n_components=2,random_state=0,copy=False)
pca.fit_transform(X[:,:2])
X=pca.transform(X)
pca.components_
pca.explained_variance_
pca.explained_variance_ratio_
pca.mean_
pca.n_components_
pca.features_
X=X*0
array[:5,:2]
X=copy(array[:,:8])
x1=copy(X)
