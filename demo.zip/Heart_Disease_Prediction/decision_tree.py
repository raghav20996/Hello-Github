import pandas as pd
import numpy as np



from sklearn.tree import DecisionTreeClassifier




'''
from sklearn.model_selection import cross_val_score
scores = cross_val_score(clf, X, Y, cv=skf)
scores.mean()
scores.std()

for x,y in skf.split(X,Y):
    print(y)
columns = ['sex','cp','exang','slope','ca','thal','target']
columns2 = ['sex','cp','exang','oldpeak','slope','ca','thal','target']
columns3 = ['sex','cp','exang','thalach','oldpeak','slope','ca','thal','target']
dataset2 = dataset[columns3]
array=np.array(dataset2)
np.random.seed(0)
np.random.shuffle(array)

X=deepcopy(array[:,:8])
Y=deepcopy(array[:,8])

# 10 CV
acc1=[]
i=0

for x in range(10):
    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.1,random_state=0)
    #x_test=X[i:i+60]
    #y_test=Y[i:i+60]
    #x_train=np.concatenate((X[:i],X[i+60:]))
    #y_train=np.concatenate((Y[:i],Y[i+60:]))
    clf.fit(x_train,y_train)
    acc1.append(clf.score(x_test,y_test))
    #i+=60
    
# 5 CV

acc6=[]
i=0

for x in range(5):
    x_test=X[i:i+60]
    y_test=Y[i:i+60]
    x_train=np.concatenate((X[:i],X[i+60:]))
    y_train=np.concatenate((Y[:i],Y[i+60:]))
    clf.fit(x_train,y_train)
    acc6.append(clf.score(x_test,y_test))
    i+=60
    
from sklearn.preprocessing import PowerTransformer
pt = PowerTransformer(copy=False)
pt.fit_transform(array[:,3:5])
'''
clf = DecisionTreeClassifier(min_samples_split=6,random_state=0)
acc1=[]
tn1=[]
fp1=[]
fn1=[]
tp1=[] 
for x,y in skf.split(X,Y):
    x_train=X[x]
    x_test=X[y]
    y_train=Y[x]
    y_test=Y[y]
    clf.fit(x_train,y_train)
    y_pred=clf.predict(x_test)
    a, b, c, d = confusion_matrix(y_test,y_pred,normalize='true').ravel()
    tn1.append(a)
    fp1.append(b)
    fn1.append(c)
    tp1.append(d)
    acc1.append(clf.score(x_test,y_test))
    
st.mean(acc1)
st.mean(tn1)
st.mean(fp1)
st.mean(fn1)
st.mean(tp1)

a=tp1[np.argsort(fp1)[9]]
tp1.append(0)
fp1.append(0)
tp1.append(.875)
fp1.append(1)
xs1, ys1 = zip(*sorted(zip(fp1, tp1)))

del ys6[11]
ys6.append(.875)
