import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
dataset=pd.read_csv('dataset.csv')
dataset.info()
a=dataset.describe()
dataset.head()
dataset.tail()
b=dataset.dtypes
a=dataset.get_dtype_counts()
dataset.select_dtypes(exclude=['float64'])
test=5
print(test)
corr_matrix=dataset.corr()
dataset['slope']=dataset['slope'].astype('category')
dataset['sex']=dataset['sex'].astype('category')
dataset['cp']=dataset['cp'].astype('category')
dataset['fbs']=dataset['fbs'].astype('category')
dataset['restecg']=dataset['restecg'].astype('category')
dataset['exang']=dataset['exang'].astype('category')
dataset['ca']=dataset['ca'].astype('category')
dataset['thal']=dataset['thal'].astype('category')
dataset['target']=dataset['target'].astype('category')
numerical_data=dataset.select_dtypes(exclude=['category'])
categorical_data=dataset.select_dtypes(include=['category'])
corr_matrix=numerical_data.corr()
sns.pairplot(numerical_data,kind='kde')
sns.boxplot(x=dataset['target'],y=dataset['age'])
pd.crosstab(index=dataset['ca'],columns=dataset['thal'])
sns.countplot(x='target',data=dataset)

'''
for x in numerical_data.columns:
    plt.scatter(numerical_data.index,numerical_data[x])
    plt.show()
    
tr=list(dataset['oldpeak'])
tr.sort()
plt.scatter(dataset.index,)
import numpy as np 
import statsmodels.api as sm 
import pylab as py
data_points = dataset['oldpeak']     
  
sm.qqplot(data_points, line ='45')
py.show()

from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
X=np.array(dataset.loc[:,:'thal'])
Y=np.array(dataset['target'])

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
#X, y = load_iris(return_X_y=True)
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2,random_state=0)
gnb = GaussianNB()
y_pred = gnb.fit(X_train, y_train).predict(X_test)
print("Number of mislabeled points out of a total %d points : %d" % (X_test.shape[0], (y_test != y_pred).sum()))
from sklearn.naive_bayes import CategoricalNB
clf = CategoricalNB()
y_pred = clf.fit(x_train, y_train).predict(x_test)
print("Number of mislabeled points out of a total %d points : %d" % (x_test.shape[0], (y_test != y_pred).sum()))

from mixed_naive_bayes import MixedNB
x_train=X[:212,:]
y_train=Y[:212]
x_test=X[212:,:]
y_test=Y[212:]
clf = MixedNB(categorical_features=[1,2,5,6,8,10,11,12])
clf.fit(x_train,y_train)

y_pred=clf.predict(x_test)
print("Number of mislabeled points out of a total %d points : %d" % (x_test.shape[0], (y_test != y_pred).sum()))

plt.hist(array[:,1],edgecolor='white',bins=5)
sns.distplot(dataset['trestbps'],kde='False',bins=4,hue=dataset['target'])

b=list(dataset['trestbps']).sort


from sklearn.cluster import KMeans
import numpy as np
A = np.array(dataset['trestbps']).reshape(-1,1)
score=[]
iterations=[]
for x in range(5,40):
  kmeans = KMeans(n_clusters=x,n_init=5,max_iter=20, random_state=0).fit(A)
  iterations.append(kmeans.n_iter_)
  
print(kmeans.n_iter_)

labels=kmeans.labels_
plt.hist(labels,bins=35)

from sklearn.ensemble import RandomForestClassifier
clf = RandomForestClassifier(n_estimators=110,bootstrap=False,random_state=0)
clf.fit(x_train,y_train)
clf.score(x_test,y_test)
clf.n_features_
clf.classes_
clf.score(x_test,y_test)
clf.predict_proba(x_test)
clf.base_estimator_
clf.estimators_
params=clf.get_params
clf.set_params(params)
clf.feature_importances_
del dataset['fbs']
del dataset['restecg']
del dataset['slope']

from sklearn.neighbors import NearestNeighbors
neigh = NearestNeighbors(n_neighbors=5,algorithm='auto')
neigh.fit(x_train,y_train)
y=neigh.predict(x_test)

from sklearn.neighbors import KNeighborsClassifier
knn_scores = []
for k in range(1,20,2):
    knn_classifier = KNeighborsClassifier(n_neighbors = k)
    knn_classifier.fit(x_train, y_train)
    knn_scores.append(knn_classifier.score(x_test, y_test))

from sklearn.preprocessing import StandardScaler
standardScaler = StandardScaler()
columns_to_scale = ['age','trestbps','chol','thalach','oldpeak']
dataset[columns_to_scale] = standardScaler.fit_transform(dataset[columns_to_scale])

dataset = pd.get_dummies(dataset, columns = ['sex', 'cp', 'fbs', 'restecg', 'exang', 'slope', 'ca', 'thal'])

y = dataset['target']
x = dataset.drop(['target'], axis = 1)
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.33, random_state = 0)

from sklearn.linear_model import LogisticRegression
acc2=[]
for x in range(10):
    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=.2,random_state=x)
    clf.fit(X,Y)
    acc2.append(clf.score(x_test,y_test)*100)
clf.n_iter_
clf.classes_

for y in range(10):
    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=.2,random_state=y)
    clf.fit(x_train,y_train)
    print(clf.score(x_train,y_train))
    
acc2=[]
i=0

for x in range(10):
    #x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.1)
    x_test=X[i:i+30]
    y_test=Y[i:i+30]
    x_train=np.concatenate((X[:i],X[i+30:]))
    y_train=np.concatenate((Y[:i],Y[i+30:]))
    i+=30
    clf.fit(x_train,y_train)
    
    
    acc2=[]
i=0

for x in range(10):
    #x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.1)
    x_test=X[i:i+30]
    y_test=Y[i:i+30]
    x_train=np.concatenate((X[:i],X[i+30:]))
    y_train=np.concatenate((Y[:i],Y[i+30:]))
    i+=30
    clf.fit(x_train,y_train)
    acc2.append(clf.score(x_test,y_test))
    
from sklearn.feature_selection import chi2
chi2(X,Y)

from sklearn.feature_selection import f_classif
f_classif(X,Y)

from sklearn.feature_selection import RFECV
from sklearn.tree import DecisionTreeClassifier
estimator = DecisionTreeClassifier(min_samples_split=5,random_state=0)

selector = RFECV(estimator, step=1, cv=5)
selector = selector.fit(X, Y)
selector.support_
array([ True,  True,  True,  True,  True, False, False, False, False,
       False])
selector.ranking_
array([1, 1, 1, 1, 1, 6, 4, 3, 2, 5])

selector.grid_scores_

from sklearn.ensemble import RandomForestClassifier
estimator = RandomForestClassifier(min_samples_split=5, random_state=0)
'''
from sklearn.linear_model import LogisticRegression
clf = LogisticRegression(random_state=0,max_iter=100)

acc4=[]
tn4=[]
fp4=[]
fn4=[]
tp4=[] 
for x,y in skf.split(X,Y):
    x_train=X[x]
    x_test=X[y]
    y_train=Y[x]
    y_test=Y[y]
    clf.fit(x_train,y_train)
    y_pred=clf.predict(x_test)
    a, b, c, d = confusion_matrix(y_test,y_pred,normalize='true').ravel()
    tn4.append(a)
    fp4.append(b)
    fn4.append(c)
    tp4.append(d)
    acc4.append(clf.score(x_test,y_test))
    
st.mean(acc4)
st.mean(tn4)
st.mean(fp4)
st.mean(fn4)
st.mean(tp4)

a=tp4[np.argsort(fp4)[9]]
tp4.append(0)
fp4.append(0)
tp4.append(a)
fp4.append(1)
xs4, ys4 = zip(*sorted(zip(fp4, tp4)))
'''
from sklearn.feature_selection import SelectFromModel
selector = SelectFromModel(estimator,threshold='mean').fit(X, Y)
selector.estimator_.coef_
array([[-0.3252302 ,  0.83462377,  0.49750423]])
selector.threshold_
0.55245...
selector.get_support()
array([False,  True, False])

from sklearn.linear_model import LogisticRegressionCV
estimator = LogisticRegressionCV(cv=10,max_iter=100, random_state=0).fit(X,Y)
estimator.score(X,Y)

from sklearn.preprocessing import OrdinalEncoder
enc = OrdinalEncoder()
test=pd.read_csv('test.csv')

array=np.array(test)
enc.fit(array)
enc.categories_
X=array1[:,:4]
Y=array1[:,4]
array1=enc.transform(array)

from sklearn.tree import DecisionTreeClassifier
clf = DecisionTreeClassifier(random_state=0)
clf.fit(X,Y)

from sklearn.tree import plot_tree
plot_tree(clf,label='none',impurity=False)

from sklearn.preprocessing import OneHotEncoder
enc = OneHotEncoder(handle_unknown='ignore')
enc.fit_transform(X)
X=enc.transform(X)
'''
count=0
n=7
#inp=input()
li=[3,3,3,4,4,4,4]
#li.sort()
i=0
while i<n:
    j=i+1
    while j<n and li[j]==li[i]:
        j=j+1
    diff=j-i
    x=3
    while x<=diff:
        count=count+comb(diff,x)
        x=x+1
    i=j
    
def comb(diff,x):
    return (fact(diff)/(fact(x)*fact(diff-x)))

def fact(x):
    if x==0:
        return 1
    else:
        return (x*fact(x-1))
    
n,m=map(int,input().split())
arr=set(map(int,input().split()))

n,m=map(int,input().split())
arr=list(set(map(int,input().split())))
a=list(map(int,input().split()))
b=list(map(int,input().split()))
happy=0
a.sort()
b.sort()
la=lb=0
ra=rb=m-1
ma=mb=(m-1)//2
#i=5
for i in arr:
    while(la<=ra and a[ma]!=i):
        if(a[ma]<i):
            la=ma+1
        else:
            ra=ma-1
        ma=(la+ra)//2
    if(a[ma]==i):
        happy+=1
    else:
        while(lb<=rb and b[mb]!=i):
            if(b[mb]<i):
                lb=mb+1
            else:
                rb=mb-1
            mb=(lb+rb)//2
        if(b[mb]==i):
            happy-=1
    print(happy)
    la=lb=0
    ra=rb=m-1
    ma=mb=(m-1)//2
print(happy)
    
    