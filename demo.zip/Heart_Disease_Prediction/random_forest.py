import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import statistics as st

'''
from sklearn.model_selection import train_test_split

from sklearn.preprocessing import PowerTransformer



dataset=pd.read_csv('dataset.csv')

columns3 = ['sex','cp','exang','thalach','oldpeak','slope','ca','thal','target']
dataset2 = dataset[columns3]
array=np.array(dataset2)

pt = PowerTransformer(copy=False)
pt.fit_transform(array[:,2:5])

np.random.seed(0)
np.random.shuffle(array)



dataset.drop(columns=['age'],inplace=True)
X=np.array(dataset.loc[:,:'thal'])
Y=np.array(dataset['target'])

x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.2,random_state=0)

clf = RandomForestClassifier(n_estimators=50,min_samples_split=6,random_state=0,max_samples=0.9)

X=array[:,:8]
Y=array[:,8]

# 10 CV
acc4=[]
i=0

for x in range(10):
    x_test=X[i:i+30]
    y_test=Y[i:i+30]
    x_train=np.concatenate((X[:i],X[i+30:]))
    y_train=np.concatenate((Y[:i],Y[i+30:]))
    clf.fit(x_train,y_train)
    acc4.append(clf.score(x_test,y_test))
    i+=30
    
maxi=[]

for x in range(10,110,10):
    clf = RandomForestClassifier(n_estimators=x,min_samples_split=6,random_state=0)
    acc=[]
    i=0
    for y in range(3):
        x_test=X[i:i+90]
        y_test=Y[i:i+90]
        x_train=np.concatenate((X[:i],X[i+90:]))
        y_train=np.concatenate((Y[:i],Y[i+90:]))
        clf.fit(x_train,y_train)
        acc.append(clf.score(x_test,y_test))
        i+=90
        
    #maxi.append(acc[5])
    maxi.append(max(acc))
    

for x in range(.1,.4,-.05):
   x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=.4,random_state=0)

   
   clf.fit(x_train,y_train)
   acc.append(clf.score(x_test,y_test))
   
print('Accuracy : %.5f' %st.mean(acc))
print('Variance : %.5f' %st.variance(acc))

acc1=[]
i=0

for x in range(10):
    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.1)
    x_test=X[i:i+30]
    y_test=Y[i:i+30]
    x_train=np.concatenate((X[:i],X[i+30:]))
    y_train=np.concatenate((Y[:i],Y[i+30:]))
    i+=30
    clf.fit(x_train,y_train)
    acc1.append(clf.score(x_test,y_test))
    
print(st.mean(acc1),st.variance(acc1))

from sklearn.tree import DecisionTreeClassifier
clf = DecisionTreeClassifier(random_state=0)

for split in [.1,.15,.2,.25,.3,.35]:
    acc=[]
    for x in range(10):
        x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=.2,random_state=x)
        clf.fit(x_train,y_train)
        acc.append(clf.score(x_test,y_test)*100)
    print(acc)
    print(st.mean(acc),st.stdev(acc),max(acc),min(acc))
    
acc1=clf.feature_importances_
sum(acc1)
        
clf.get_n_leaves

from sklearn import tree
tree.plot_tree(clf.fit(x_train, y_train)) 
'''
result1=np.ones((10,11))
result2=np.ones((10,6))
#acc=[]
for z in range(10,110,10):
    clf = RandomForestClassifier(n_estimators=z,min_samples_split=6,random_state=0)
    tn2=[]
    fp2=[]
    fn2=[]
    tp2=[] 
    j=(z-10)//10
    result1[j][0]=z
    #scores = cross_val_score(clf, X, Y, cv=skf)
    i=1
    for x,y in skf.split(X,Y):
        #result3[j,y]=scores[y-1]#i=0
    #for y in range(10):
        #x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=.2,random_state=y)
        #i+=1
        #if(i==6):
        x_test=X[y]
        y_test=Y[y]
        x_train=X[x]
        y_train=Y[x]
        #i+=60
        #pca.fit(X[x])
        #x_train=pca.transform(X[x])
        #x_test=pca.transform(X[y])
        clf.fit(x_train,y_train)
        y_pred=clf.predict(x_test)
        a, b, c, d = confusion_matrix(y_test,y_pred,normalize='true').ravel()
        tn2.append(a)
        fp2.append(b)
        fn2.append(c)
        tp2.append(d)
        result1[j][i]=clf.score(x_test,y_test)
        i+=1
        
    result2[j][0]=z
    result2[j][1]=result1[j,1:].mean()
    result2[j][2]=st.mean(tn2)
    result2[j][3]=st.mean(fp2) #min(result3[j,1:])
    result2[j][4]=st.mean(fn2) #max(result3[j,1:])
    result2[j][5]=st.mean(tp2)
    
a=tp2[np.argsort(fp2)[9]]
tp2.append(0)
fp2.append(0)
tp2.append(a)
fp2.append(1)
xs2, ys2 = zip(*sorted(zip(fp2, tp2)))
    
result3[:,1:]=result3[:,1:]*100
    

    
knn1=pd.DataFrame(result3,columns=['k','sample1','sample2','sample3','sample4','sample5','sample6','sample7','sample8','sample9','sample10'])
knn2=pd.DataFrame(result4,columns=['k','avg.acc','st.dev.','min.acc','max.acc'])
'''
random1.drop(labels='Index',axis=1,inplace=True)

clf = RandomForestClassifier(n_estimators=10,min_samples_split=6,random_state=0)
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=.2,random_state=7)
clf.fit(x_train,y_train)
clf.score(x_test,y_test)
'''