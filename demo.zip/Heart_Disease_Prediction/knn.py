
from sklearn.neighbors import KNeighborsClassifier



'''scaler.data_range_

maxi=[]


for x in range(1,21):
    clf = KNeighborsClassifier(n_neighbors=x,algorithm='brute')
    acc=[]
    i=0
    for y in range(10):
        x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=.2,random_state=y)
        #x_test=X[i:i+60]
        #y_test=Y[i:i+60]
        #x_train=np.concatenate((X[:i],X[i+60:]))
        #y_train=np.concatenate((Y[:i],Y[i+60:]))
        clf.fit(x_train,y_train)
        acc.append(clf.score(x_test,y_test))
        #i+=60
        
    #maxi.append(acc[5])
    maxi.append(max(acc))
''''    
    
result3=np.ones((20,11))
result4=np.ones((20,6))

for z in range(1,21):
    clf = KNeighborsClassifier(n_neighbors=z,algorithm='brute')
    tn3=[]
    fp3=[]
    fn3=[]
    tp3=[]
    j=z-1
    result3[j][0]=z
    i=1
    for x,y in skf.split(X,Y):
        x_test=X[y]
        y_test=Y[y]
        x_train=X[x]
        y_train=Y[x]
        #scaler.fit_transform(x_train[:,3:5])
        clf.fit(x_train,y_train)
        #scaler.transform(x_test[:,3:5])
        y_pred=clf.predict(x_test)
        a, b, c, d = confusion_matrix(y_test,y_pred,normalize='true').ravel()
        tn3.append(a)
        fp3.append(b)
        fn3.append(c)
        tp3.append(d)
        result3[j][i]=clf.score(x_test,y_test)
        i+=1
        
    result4[j][0]=z
    result4[j][1]=result3[j,1:].mean()
    result4[j][2]=st.mean(tn3) #result3[j,1:].std()
    result4[j][3]=st.mean(fp3) #min(result3[j,1:])
    result4[j][4]=st.mean(fn3) #max(result3[j,1:])
    result4[j][5]=st.mean(tp3)
    
a=tp3[np.argsort(fp3)[9]]
tp3.append(0)
fp3.append(0)
tp3.append(a)
fp3.append(1)
xs3, ys3 = zip(*sorted(zip(fp3, tp3)))
    
plt.plot([k for k in range(1, 21)], result4[:,1], color = 'red')
for i in range(1,21):
    plt.text(i, result4[[i-1,1], (i, result4[i-1,1]))
plt.xticks([i for i in range(1, 21)])
plt.xlabel('Number of Neighbors (K)')
plt.ylabel('Scores')
plt.title('K Neighbors Classifier scores for different K values')

 '''   for y in range(10):
        x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=.2,random_state=y)
        clf.fit(x_train,y_train)
        result3[i][y+1]=clf.score(x_test,y_test)
    
    result4[i][0]=x
    result4[i][1]=st.mean(result3[i,1:])
    result4[i][2]=st.stdev(result3[i,1:])
    result4[i][3]=min(result3[i,1:])
    result4[i][4]=max(result3[i,1:])'''