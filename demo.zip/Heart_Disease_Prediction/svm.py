from sklearn.svm import SVC

'''clf.fit(x_train,y_train)
clf.score(x_test,y_test)
clf.support_
clf.n_support_
clf.classes_
clf.fit_status_'''
from sklearn.model_selection import GridSearchCV
parameters = {'kernel':('linear', 'rbf','poly','sigmoid'), 'degree':(1,2,3),'gamma':('scale','auto')}
svc = SVC()
clf = GridSearchCV(svc, parameters,cv=10)
clf.fit(X,Y)
clf.best_params_

clf=SVC()
acc6=[]
tn6=[]
fp6=[]
fn6=[]
tp6=[] 
for x,y in skf.split(X,Y):
    x_train=X[x]
    x_test=X[y]
    y_train=Y[x]
    y_test=Y[y]
    clf.fit(x_train,y_train)
    y_pred=clf.predict(x_test)
    a, b, c, d = confusion_matrix(y_test,y_pred,normalize='true').ravel()
    tn6.append(a)
    fp6.append(b)
    fn6.append(c)
    tp6.append(d)
    acc6.append(clf.score(x_test,y_test))
    
st.mean(acc6)
st.mean(tn6)
st.mean(fp6)
st.mean(fn6)
st.mean(tp6)
a=tp6[np.argsort(fp6)[9]]
tp6.append(0)
fp6.append(0)
tp6.append(a)
fp6.append(1)
tp6.sort()

import matplotlib.pyplot as plt
import numpy as np

x = # false_positive_rate
y = # true_positive_rate 
xs6, ys6 = zip(*sorted(zip(fp6, tp6)))
# This is the ROC curve
plt.plot(xs6,ys6,label='svm')
plt.plot(xs1,ys1,label='DT')
plt.plot(xs2,ys2,label='RF')
plt.plot(xs3,ys3,label='KNN')
plt.plot(xs4,ys4,label='LR')
plt.plot(xs5,ys5,label='NB')
plt.legend()
plt.xlabel('FP')
plt.ylabel('TP')
plt.show() 

# This is the AUC
np.trapz(ys6,xs6)
np.trapz(ys5,xs5)
np.trapz(ys4,xs4)
np.trapz(ys3,xs3)
np.trapz(ys2,xs2)
np.trapz(ys1,xs1)
np.argsort(fp6)
