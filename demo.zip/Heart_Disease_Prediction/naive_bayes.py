import pandas as pd
import numpy as np
from copy import *
from sklearn.preprocessing import MinMaxScaler

from sklearn.naive_bayes import CategoricalNB
from sklearn.naive_bayes import GaussianNB
gnb = GaussianNB()
cnb = CategoricalNB()
for x,y in skf.split(X,Y):
    x_test=X[y]
    y_test=Y[y]
    x_train=X[x]
    y_train=Y[x]
    cnb.fit(x_train[:,5:],y_train)  # extracting categorical features
    gnb.fit(x_train[:,:5],y_train)  # extracting numerical features
    

import statistics as st
import pandas as pd
df=pd.read_csv('dataset.csv')
columns = ['trestbps','chol','age','thalach','oldpeak','fbs','restecg','sex','cp','exang','slope','ca','thal','target']
columns = ['age','chol','thalach','oldpeak','sex','cp','exang','slope','ca','thal','target']

dataset2 = dataset[columns]
array=np.array(dataset2)
X=copy(array[:,:13])
Y=array[:,13]

scaler = MinMaxScaler(feature_range=(0,4),copy=False)
scaler.fit_transform(X[:,:5])

from sklearn.model_selection import StratifiedKFold
skf = StratifiedKFold(n_splits=10,shuffle=True,random_state=0)

from sklearn.metrics import confusion_matrix
'''
from mixed_naive_bayes import MixedNB
from sklearn.model_selection import train_test_split



dataset=pd.read_csv('dataset.csv')


np.random.seed(0)
np.random.shuffle(array)






result=np.ones((10,4))
#result2=np.ones((8,4))

for x in range(10):
    clf = RandomForestClassifier(n_estimators=x,min_samples_split=4,random_state=0)
    i=(x-30)//10
    for y in range(10):
        x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=.1,random_state=0)
        clf.fit(x_train,y_train)
        result1[i][y]=clf.score(x_test,y_test)
        
    result2[i][0]=st.mean(result1[i])
    result2[i][1]=st.stdev(result1[i])
    result2[i][2]=min(result1[i])
    result2[i][3]=max(result1[i])
clf = MixedNB(categorical_features=[1,2,5,6,8,10,11,12])
acc=[]
i=0
'''
gnb = GaussianNB()
clf = CategoricalNB()
acc5=[]
tn5=[]
fp5=[]
fn5=[]
tp5=[]
for x,y in skf.split(X,Y):
    #x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.2,random_state=x)
    #x_test=X[i:i+60]
    #y_test=Y[i:i+60]
    #x_train=np.concatenate((X[:i],X[i+60:]))
    #y_train=np.concatenate((Y[:i],Y[i+60:]))
    #i+=30
    x_test=X[y]
    y_test=Y[y]
    x_train=X[x]
    y_train=Y[x]
    #pt.fit_transform(x_train[:,:2])
    #pt.transform(x_test[:,:2])
    clf.fit(x_train[:,5:],y_train)
    gnb.fit(x_train[:,:5],y_train)
    array1=clf.predict_log_proba(x_test[:,5:])
    array2=gnb.predict_log_proba(x_test[:,:5])
    array3=np.add(array1,array2)
    z=x_test.shape[0]
    y_pred=np.arange(0.0,z,1)
    for y in range(z):
        if array3[y][0]>array3[y][1]:
            y_pred[y]=0
        else:
            y_pred[y]=1
    #y_pred=clf.predict(x_test)
#print("Number of mislabeled points out of a total %d points : %d" % (x_test.shape[0], (y_test != y_pred).sum()))
    a, b, c, d = confusion_matrix(y_test,y_pred,normalize='true').ravel()
    tn5.append(a)
    fp5.append(b)
    fn5.append(c)
    tp5.append(d)
    #acc1.append(clf.score(x_test,y_test)
    right=(y_test == y_pred).sum()
    acc5.append((right/z)*100)
    #acc4.append(gnb.score(x_test,y_test))
    #i+=60
    
st.mean(acc5)
st.mean(tn5)
st.mean(fp5)
st.mean(fn5)
st.mean(tp5)

a=tp5[np.argsort(fp5)[9]]
tp5.append(0)
fp5.append(0)
tp5.append(a)
fp5.append(1)
xs5, ys5 = zip(*sorted(zip(fp5, tp5)))
    
'''plt.hist(tr,edgecolor='white',bins=[-1.17,-.021,2.11])
predict=clf.predict_proba(x_test)
    
tr = np.array(dataset['oldpeak'])  
print('Accuracy : %.2f' %st.mean(acc))
print('Variance : %.2f' %st.stdev(acc))

columns2=['thalach','oldpeak','target']
from sklearn.preprocessing import PowerTransformer
pt = PowerTransformer(copy=False)
pt.fit_transform(array[:,2:5])
tr1=pt.transform(tr.reshape(-1,1))


x_=X[:,0:2]
tr=tr1.reshape(303,)
st.mean(dataset['oldpeak'])
st.mean(tr)
tr=list(tr)
min(array[:,7])
dataset['thal'].value_counts()
'''

df=pd.DataFrame([['accuracy','NB',84.2],['accuracy','DT',74.6],['accuracy','RF',82.9],['accuracy','KNN',84.9],['accuracy','LR',81.5],['sensitivity','NB',87.9],['sensitivity','DT',76.5],['sensitivity','RF',87.3],['sensitivity','KNN',89.2],['sensitivity','LR',86.6],['specificity','NB',79.8],['specificity','DT',72.6],['specificity','RF',77.6],['specificity','KNN',79.8],['specificity','LR',75.4]],columns=['param','clf','value'])
df.pivot('param','clf','value').plot(kind='bar')
from matplotlib.cm import rainbow
from matplotlib import rcParams
kernels=['NB','DT','RF','KNN','LR']
svc_scores=[79.8,72.6,77.6,79.8,75.4]
colors = rainbow(np.linspace(0, 1, len(kernels)))
#rcParams['figure.figsize'] = 8,6
plt.bar(kernels, svc_scores,color = colors)
for i in range(len(kernels)):
    plt.text(i, svc_scores[i], svc_scores[i])
plt.xlabel('Classifiers')
plt.ylabel('Specificity')
